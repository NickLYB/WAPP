﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Masters/Tutor.Master" AutoEventWireup="true" CodeBehind="Chat.aspx.cs" Inherits="WAPP.Pages.Tutor.Chat" MaintainScrollPositionOnPostback="true" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style>
        /* Sleek styling for the video call popup */
        #videoCallModal .modal-content { background-color: #1a1d20; border-radius: 12px; }
        
        /* The container for the WhatsApp/Teams style layout */
        .video-wrapper {
            position: relative;
            width: 100%;
            height: 500px;
            background-color: #000;
            border-radius: 8px;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* The Partner's Video (Main Screen) */
        .video-remote {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: none; /* Hidden until they answer */
        }

        /* Your Video (Picture-in-Picture Bottom Right) */
        .video-local-pip {
            position: absolute;
            bottom: 20px;
            right: 20px;
            width: 130px;
            height: 180px;
            object-fit: cover;
            border: 2px solid #fff;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.5);
            z-index: 10;
            background: #222;
            transition: all 0.3s ease;
        }

        /* Overlay text for "Calling..." state */
        .call-status-overlay {
            position: absolute;
            color: white;
            font-size: 1.2rem;
            text-align: center;
            z-index: 5;
        }
    </style>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div class="ec-content-wrapper">
        <div class="ec-item-gap">
                <asp:SiteMapPath ID="SiteMapPath1" runat="server" SiteMapProvider="TutorMap" 
                    PathSeparator=" > " CssClass="small text-muted text-decoration-none" RenderCurrentNodeAsLink="false" />
            </div>
        <div class="ec-section-gap">
            <h1 class="ec-page-title">Messages</h1>
            <p class="ec-page-subtitle">Communicate with your students in real-time.</p>
        </div>

        <div class="ec-chat-layout">
            
            <div class="ec-chat-sidebar">
                <div class="p-3 border-bottom bg-white">
                    <asp:TextBox ID="txtSearch" runat="server" ClientIDMode="Static" CssClass="login-input m-0" 
                        placeholder="Search students..." style="padding: 10px 15px; font-size: 0.9rem;"
                        onkeyup="handleLiveSearch(event)"></asp:TextBox>
                </div>
    
                <div class="ec-chat-list">
                    <asp:UpdatePanel ID="upContacts" runat="server" UpdateMode="Conditional">
                        <ContentTemplate>
                            <asp:Button ID="btnSearchTrigger" runat="server" ClientIDMode="Static" OnClick="btnSearchTrigger_Click" style="display:none;" />
                            <asp:Button ID="btnRefreshSidebar" runat="server" ClientIDMode="Static" OnClick="btnRefreshSidebar_Click" style="display:none;" />
            
                            <asp:Repeater ID="rptContacts" runat="server" OnItemCommand="rptContacts_ItemCommand">
                                <ItemTemplate>
                                    <asp:LinkButton ID="lnkContact" runat="server" 
                                        CommandName="SelectContact" 
                                        CommandArgument='<%# Eval("UserId") + "|" + Eval("UserName") %>'
                                        CssClass='<%# Convert.ToInt32(Eval("UserId")) == ActiveContactId ? "ec-chat-contact active" : "ec-chat-contact" %>'>
                        
                                        <div class="d-flex justify-content-between align-items-center w-100">
                                            <div>
                                                <div class="small fw-bold"><%# Eval("UserName") %></div>
                                                <small class="text-muted">Tap to message</small>
                                            </div>
                            
                                            <asp:Label runat="server" 
                                                Visible='<%# Convert.ToInt32(Eval("UnreadCount")) > 0 %>' 
                                                CssClass="badge bg-danger rounded-pill">
                                                <%# Eval("UnreadCount") %>
                                            </asp:Label>
                                        </div>
                                    </asp:LinkButton>
                                </ItemTemplate>
                            </asp:Repeater>
            
                            <asp:Label ID="lblNoContacts" runat="server" Visible="false" CssClass="text-muted small d-block text-center mt-4">
                                No conversations found.
                            </asp:Label>
                        </ContentTemplate>
                    </asp:UpdatePanel>
                </div>
            </div>

            <div class="ec-chat-window">
                <asp:UpdatePanel ID="upChatArea" runat="server" UpdateMode="Conditional" style="height: 100%; display: flex; flex-direction: column;">
                    <ContentTemplate>
                        <asp:HiddenField ID="hfMyId" runat="server" ClientIDMode="Static" />
                        <asp:HiddenField ID="hfCurrentContactId" runat="server" ClientIDMode="Static" />
                        <asp:Button ID="btnRefreshChat" runat="server" ClientIDMode="Static" OnClick="btnRefreshChat_Click" style="display:none;" />

                        <div class="p-3 border-bottom bg-white d-flex justify-content-between align-items-center">
                            <h6 class="fw-bold m-0 text-dark">
                                <i class="bi bi-person-circle me-2 text-primary"></i>
                                <asp:Label ID="lblChatHeader" runat="server" Text="SELECT A CONVERSATION"></asp:Label>
                            </h6>
                            
                            <button type="button" id="btnStartCall" class="btn btn-sm btn-outline-primary rounded-pill px-3 fw-bold" onclick="startCall()" style="display:none;">
                                <i class="bi bi-camera-video-fill me-1"></i> Video Call
                            </button>
                        </div>

                        <div class="ec-chat-messages" id="chatMessagesContainer">
                            <asp:Repeater ID="rptMessages" runat="server">
                                <ItemTemplate>
                                    <div class='<%# Convert.ToInt32(Eval("sender_id")) == LoggedInUserId ? "ec-msg-wrapper sent" : "ec-msg-wrapper received" %>'>
                                        <div class="ec-msg-bubble shadow-sm">
                                            <%# Eval("message_text") %>
                                        </div>
                                        <small class="text-muted mt-1" style="font-size: 0.7rem;">
                                            <%# Eval("SenderName") %> • <%# Convert.ToDateTime(Eval("created_at")).ToString("MMM dd, hh:mm tt") %>
                                        </small>
                                    </div>
                                </ItemTemplate>
                            </asp:Repeater>

                            <asp:PlaceHolder ID="phNoMessages" runat="server" Visible="false">
                                <div class="ec-empty-state">
                                    <i class="bi bi-chat-dots"></i>
                                    <p>Start a conversation with this student.</p>
                                </div>
                            </asp:PlaceHolder>
                        </div>

                        <div class="ec-chat-footer">
                            <asp:TextBox ID="txtMessage" runat="server" CssClass="login-input m-0" 
                                placeholder="Write your message..." Enabled="false"></asp:TextBox>
                            <asp:Button ID="btnSend" runat="server" Text="Send" 
                                CssClass="btn-main btn-pill px-4" OnClick="btnSend_Click" Enabled="false" />
                        </div>

                    </ContentTemplate>
                </asp:UpdatePanel>
            </div>

        </div>
    </div>

    <div class="modal fade" id="videoCallModal" data-bs-backdrop="static" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content border-0 shadow-lg">
                <div class="modal-header border-bottom-0 pb-0">
                    <h5 class="modal-title fw-bold text-white">Video Call</h5>
                    <button type="button" class="btn-close btn-close-white" onclick="endCall()"></button>
                </div>
                <div class="modal-body">
                    
                    <div class="video-wrapper">
                        <div class="call-status-overlay" id="videoCallOverlay">
                            <div class="spinner-border text-primary mb-3" role="status" style="width: 3rem; height: 3rem;"></div>
                            <div id="videoCallStatusText" class="fw-bold">Calling partner...</div>
                        </div>

                        <video id="remoteVideo" class="video-remote" autoplay playsinline></video>
                        
                        <video id="localVideo" class="video-local-pip" autoplay playsinline muted></video>
                    </div>

                </div>
                <div class="modal-footer border-top-0 justify-content-center pt-0 pb-4">
                    <button type="button" id="btnShareScreen" class="btn btn-secondary rounded-pill px-4 fw-bold me-2" onclick="toggleScreenShare()">
                        <i class="bi bi-display me-2"></i> Share Screen
                    </button>
                    <button type="button" class="btn btn-danger rounded-pill px-5 fw-bold" onclick="endCall()">
                        <i class="bi bi-telephone-x-fill me-2"></i> End Call
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../../Scripts/jquery.signalR-2.4.3.min.js"></script>
    <script src="../../signalr/hubs"></script>

   <script type="text/javascript">
       var typingTimer;
       var chatHub;

       // WebRTC Variables
       var peerConnection;
       var localStream;
       var screenStream = null;
       var isScreenSharing = false;
       var iceQueue = [];
       var currentCallPartnerId = null;

       // NEW: Variable to hold the servers fetched from the API
       var myIceServers = null;

       $.connection.hub.qs = { "ngrok-skip-browser-warning": "true" };
       $.ajaxSetup({ headers: { 'ngrok-skip-browser-warning': 'true' } });

       $(function () {
           // --- 1. FETCH TURN CREDENTIALS FROM API ---
           fetch("https://wapp.metered.live/api/v1/turn/credentials?apiKey=94efd7cde7e88d15b9cbd72b03e8e8131147")
               .then(response => response.json())
               .then(data => {
                   myIceServers = data; // Save the servers to our variable
                   console.log("TURN API loaded successfully!");
               })
               .catch(err => console.error("Error fetching TURN servers:", err));


           chatHub = $.connection.chatHub;

           // 2. Receive Text Messages
           chatHub.client.receiveNewMessage = function (senderId, receiverId) {
               var myId = $('#hfMyId').val();
               var currentContactId = $('#hfCurrentContactId').val();

               if ((receiverId == myId && senderId == currentContactId) || (senderId == myId && receiverId == currentContactId)) {
                   $('#btnRefreshChat').click();
               } else if (receiverId == myId) {
                   $('#btnRefreshSidebar').click();
               }
           };

           // 3. Receive Video Signals
           chatHub.client.receiveVideoSignal = async function (senderId, receiverId, dataJson) {
               var myId = $('#hfMyId').val();
               if (myId != receiverId) return;

               var signal = JSON.parse(dataJson);
               currentCallPartnerId = senderId;

               if (signal.sdp && signal.sdp.type === 'offer') {
                   if (!confirm("Incoming video call! Do you want to answer?")) return;

                   $('#videoCallModal').modal('show');
                   resetVideoUI();
                   $("#videoCallStatusText").text("Connecting...");

                   var camReady = await setupCamera();
                   if (!camReady) return;

                   if (!peerConnection) createPeerConnection();
                   await peerConnection.setRemoteDescription(new RTCSessionDescription(signal.sdp));

                   var answer = await peerConnection.createAnswer();
                   await peerConnection.setLocalDescription(answer);
                   sendSignal({ sdp: peerConnection.localDescription });

                   processIceQueue();
               } else if (signal.sdp && signal.sdp.type === 'answer') {
                   await peerConnection.setRemoteDescription(new RTCSessionDescription(signal.sdp));
                   processIceQueue();
               } else if (signal.ice) {
                   if (peerConnection && peerConnection.remoteDescription) {
                       await peerConnection.addIceCandidate(new RTCIceCandidate(signal.ice));
                   } else {
                       iceQueue.push(signal.ice);
                   }
               }
           };

           $.connection.hub.start().done(function () {
               console.log("Chat Page: SignalR Connected!");
           });
       });

       // --- Video Call Logic ---
       function resetVideoUI() {
           document.getElementById('remoteVideo').style.display = 'none';
           document.getElementById('videoCallOverlay').style.display = 'block';
           $('#btnShareScreen').html('<i class="bi bi-display me-2"></i> Share Screen');
       }

       async function setupCamera() {
           if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
               alert("Camera API blocked! Make sure you are using HTTPS.");
               return false;
           }
           try {
               const constraints = { video: { width: 640, height: 480, frameRate: 15 }, audio: true };
               localStream = await navigator.mediaDevices.getUserMedia(constraints);
               document.getElementById('localVideo').srcObject = localStream;
               return true;
           } catch (err) {
               alert("Error accessing camera: " + err.message);
               return false;
           }
       }

       function createPeerConnection() {
           // --- USE THE API SERVERS HERE ---
           var rtcConfig = myIceServers
               ? { iceServers: myIceServers }
               : { iceServers: [{ urls: "stun:stun.l.google.com:19302" }] };

           peerConnection = new RTCPeerConnection(rtcConfig);

           peerConnection.oniceconnectionstatechange = function () {
               if (peerConnection.iceConnectionState === "disconnected" || peerConnection.iceConnectionState === "failed") {
                   $("#videoCallStatusText").text("Connection lost.");
                   document.getElementById('videoCallOverlay').style.display = 'block';
                   endCall();
               }
           };

           if (localStream) {
               localStream.getTracks().forEach(track => peerConnection.addTrack(track, localStream));
           }

           // When the remote video stream arrives!
           peerConnection.ontrack = event => {
               document.getElementById('remoteVideo').srcObject = event.streams[0];

               // Hide the "Calling..." spinner and show the big remote video
               document.getElementById('videoCallOverlay').style.display = 'none';
               document.getElementById('remoteVideo').style.display = 'block';
           };

           peerConnection.onicecandidate = event => {
               if (event.candidate) sendSignal({ ice: event.candidate });
           };
       }

       async function processIceQueue() {
           while (iceQueue.length > 0) {
               await peerConnection.addIceCandidate(new RTCIceCandidate(iceQueue.shift()));
           }
       }

       async function startCall() {
           var partnerId = $('#hfCurrentContactId').val();
           if (!partnerId || partnerId == "0") return;

           currentCallPartnerId = partnerId;

           $('#videoCallModal').modal('show');
           resetVideoUI();
           $("#videoCallStatusText").text("Calling partner...");

           var camReady = await setupCamera();
           if (!camReady) {
               $('#videoCallModal').modal('hide');
               return;
           }

           createPeerConnection();
           var offer = await peerConnection.createOffer();
           await peerConnection.setLocalDescription(offer);
           sendSignal({ sdp: peerConnection.localDescription });
       }

       function sendSignal(data) {
           var myId = $('#hfMyId').val();
           chatHub.server.sendVideoSignal(myId, currentCallPartnerId, JSON.stringify(data));
       }

       // --- SCREEN SHARE LOGIC ---
       async function toggleScreenShare() {
           if (!peerConnection) return;

           if (!isScreenSharing) {
               try {
                   screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
                   const screenTrack = screenStream.getVideoTracks()[0];

                   const sender = peerConnection.getSenders().find(s => s.track.kind === 'video');
                   sender.replaceTrack(screenTrack);

                   document.getElementById('localVideo').srcObject = screenStream;
                   isScreenSharing = true;

                   $('#btnShareScreen').html('<i class="bi bi-camera-video me-2"></i> Stop Sharing');

                   screenTrack.onended = function () {
                       stopScreenShare();
                   };
               } catch (err) {
                   console.error("Error sharing screen:", err);
               }
           } else {
               stopScreenShare();
           }
       }

       async function stopScreenShare() {
           if (!isScreenSharing) return;

           const videoTrack = localStream.getVideoTracks()[0];
           const sender = peerConnection.getSenders().find(s => s.track.kind === 'video');
           sender.replaceTrack(videoTrack);

           document.getElementById('localVideo').srcObject = localStream;

           if (screenStream) {
               screenStream.getTracks().forEach(track => track.stop());
               screenStream = null;
           }

           isScreenSharing = false;
           $('#btnShareScreen').html('<i class="bi bi-display me-2"></i> Share Screen');
       }

       function endCall() {
           if (isScreenSharing) stopScreenShare();

           if (peerConnection) {
               peerConnection.close();
               peerConnection = null;
           }
           if (localStream) {
               localStream.getTracks().forEach(track => track.stop());
               localStream = null;
           }
           iceQueue = [];
           currentCallPartnerId = null;

           $('#videoCallModal').modal('hide');
           document.getElementById('localVideo').srcObject = null;
           document.getElementById('remoteVideo').srcObject = null;
       }

       // --- Search and UI logic ---
       function handleLiveSearch(event) {
           if (event.keyCode === 13) {
               event.preventDefault();
               clearTimeout(typingTimer);
               document.getElementById('btnSearchTrigger').click();
               return false;
           }
           var key = event.keyCode || event.charCode;
           if (key >= 37 && key <= 40) return;

           clearTimeout(typingTimer);
           typingTimer = setTimeout(function () {
               document.getElementById('btnSearchTrigger').click();
           }, 400);
       }

       function scrollToBottom() {
           var chatContainer = document.getElementById("chatMessagesContainer");
           if (chatContainer) { chatContainer.scrollTop = chatContainer.scrollHeight; }
       }

       function checkCallButtonVisibility() {
           var partnerId = $('#hfCurrentContactId').val();
           if (partnerId && partnerId != "0" && partnerId != "") {
               $('#btnStartCall').show();
           } else {
               $('#btnStartCall').hide();
           }
       }

       document.addEventListener("DOMContentLoaded", function () {
           scrollToBottom();
           checkCallButtonVisibility();
       });

       if (typeof Sys !== 'undefined' && Sys.WebForms && Sys.WebForms.PageRequestManager) {
           Sys.WebForms.PageRequestManager.getInstance().add_endRequest(function () {
               scrollToBottom();
               checkCallButtonVisibility();
           });
       }
   </script>
</asp:Content>